# Description
Support Addon For EscapeFromBedrockPrison V1 by Kylan1940

# Map Download
[You can download EscapeFromBedrockPrison here](https://www.planetminecraft.com/project/escape-from-bedrock-prison/)

# DON'T
>- DON'T Make A Video For This Map WITHOUT GIVING A CREDIT OF THIS MAP
>- DON'T CLAIM/EDIT/REDISTRIBUTE THIS MAP OR ANY PART OF IT TO CLAIM AS YOUR OWN WORK
>- DON'T SHARE MEDIAFIRE LINK, PLEASE SHARE With MCPEDL or PLANETMINECRAFT LINK

# LICENSE
[Apache-2.0](https://github.com/Kylan1940/MinecraftAddon/blob/main/LICENSE)